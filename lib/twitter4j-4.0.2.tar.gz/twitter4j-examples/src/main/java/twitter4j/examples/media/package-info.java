/**
 * example codes for media APIs
 */
package twitter4j.examples.media;